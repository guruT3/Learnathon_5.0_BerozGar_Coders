#!/usr/bin/env python3
"""
security_scanner.py
====================

Authorized, non-destructive security assessment scanner for the
"HostelGrievance" university web application (Student / Warden
grievance-tracking system), built for the HostelGrievance final
hardening exercise.

INTENDED USE
------------
This tool is designed to be run ONLY against a deployment you are
explicitly authorized to test (e.g. your own team's challenge
deployment, a staging environment, or a CTF-style authorized target).
It performs passive/safe active checks: it crawls same-origin pages,
inspects headers/cookies, sends small non-destructive probe requests
(harmless canary strings, conservative SQL-error probing, etc.), and
never attempts to brute force credentials, exfiltrate data, upload
dangerous files, or modify/delete application state.

The scanner focuses on the risk areas that matter most for a
Student/Warden grievance-tracking application: broken access control
(IDOR/BOLA) between students, vertical privilege escalation between
Student and Warden roles, unsafe handling of attachments, and
grievance/comment data exposure.

USAGE
-----
    python security_scanner.py --url https://target.example --all

    python security_scanner.py --url https://target.example \
        --crawl --headers --cookies --auth --access-control \
        --input --xss --sqli --files --api --disclosure --logging-check \
        --output security-tool.xml --pdf-output security-report.pdf

Optional authorized multi-account testing (for access-control /
privilege-escalation comparison) is supplied via a JSON credentials
file, never via CLI plaintext history:

    python security_scanner.py --url https://target.example --all \
        --credentials creds.json

    creds.json format:
    {
      "student_a": {"username": "...", "password": "..."},
      "student_b": {"username": "...", "password": "..."},
      "warden":    {"username": "...", "password": "..."}
    }

This script intentionally does NOT contain any exploit payloads that
extract data, escalate privileges, corrupt state, or attack systems
outside the target's own origin.
"""

from __future__ import annotations

import argparse
import dataclasses
import html
import ipaddress
import json
import re
import sys
import time
import uuid
import xml.sax.saxutils as saxutils
from collections import deque
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import urljoin, urlparse, urlsplit, parse_qs, urlencode

try:
    import requests
    from requests.adapters import HTTPAdapter
except ImportError:  # pragma: no cover
    print("This scanner requires the 'requests' package: pip install requests")
    sys.exit(1)

try:
    from bs4 import BeautifulSoup  # optional, improves HTML parsing quality
    HAVE_BS4 = True
except ImportError:  # pragma: no cover
    HAVE_BS4 = False


SCANNER_NAME = "HostelGrievance Security Assessment Scanner"
SCANNER_VERSION = "1.0.0"


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

SEVERITIES = ["Critical", "High", "Medium", "Low", "Info"]
SEVERITY_ORDER = {s: i for i, s in enumerate(SEVERITIES)}

CONFIDENCES = ["High", "Medium", "Low"]
STATUSES = ["Confirmed", "Potential", "Informational", "Manual Verification Required"]
BLAST_RADII = [
    "Single Resource", "Single User", "Multiple Users",
    "Role-wide", "Application-wide", "Unknown",
]


@dataclasses.dataclass
class Finding:
    """A single security assessment finding."""
    id: str
    title: str
    severity: str
    confidence: str
    status: str
    category: str
    url: str
    affected_component: str = "Unknown"
    attack_path: str = "Unknown"
    trust_boundary: str = "Unknown"
    blast_radius: str = "Unknown"
    description: str = ""
    evidence: str = ""
    impact: str = ""
    recommendation: str = ""
    verification: str = ""
    residual_risk: str = ""

    def as_dict(self) -> Dict[str, str]:
        return dataclasses.asdict(self)


@dataclasses.dataclass
class EndpointInfo:
    """A discovered page / endpoint."""
    url: str
    method: str = "GET"
    kind: str = "page"           # page | form | api | attachment
    params: List[str] = dataclasses.field(default_factory=list)
    source: str = "crawl"        # crawl | html | js
    role_hint: str = ""          # student | warden | unknown


@dataclasses.dataclass
class ScanConfig:
    url: str
    max_pages: int = 60
    timeout: float = 8.0
    delay: float = 0.15
    verbose: bool = False
    credentials_path: Optional[str] = None
    output_xml: str = "security-tool.xml"
    output_pdf: str = "security-report.pdf"
    do_crawl: bool = True
    do_headers: bool = False
    do_cookies: bool = False
    do_auth: bool = False
    do_access_control: bool = False
    do_input: bool = False
    do_xss: bool = False
    do_sqli: bool = False
    do_files: bool = False
    do_api: bool = False
    do_disclosure: bool = False
    do_logging_check: bool = False
    enable_upload_probe: bool = False


class FindingCollector:
    """Collects findings and hands out sequential IDs."""

    def __init__(self) -> None:
        self._findings: List[Finding] = []
        self._counter = 0
        self._seen: Set[Tuple[str, str]] = set()

    def add(self, **kwargs: Any) -> Optional[Finding]:
        # de-duplicate identical (title, url) pairs so re-crawled or
        # repeatedly-probed endpoints don't spam the report
        dedup_key = (kwargs.get("title", ""), kwargs.get("url", ""))
        if dedup_key in self._seen:
            return None
        self._seen.add(dedup_key)

        self._counter += 1
        fid = f"SEC-{self._counter:03d}"
        finding = Finding(id=fid, **kwargs)
        self._findings.append(finding)
        return finding

    def all(self) -> List[Finding]:
        return sorted(
            self._findings,
            key=lambda f: (SEVERITY_ORDER.get(f.severity, 99), f.id),
        )

    def summary(self) -> Dict[str, int]:
        counts = {s: 0 for s in SEVERITIES}
        for f in self._findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1
        return counts


def redact(value: Optional[str], keep: int = 3) -> str:
    """Redact a potentially sensitive string, keeping only a short prefix."""
    if not value:
        return ""
    value = str(value)
    if len(value) <= keep:
        return "*" * len(value)
    return value[:keep] + "*" * min(8, max(3, len(value) - keep))


def truncate(text: Optional[str], length: int = 240) -> str:
    if not text:
        return ""
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > length:
        return text[:length] + "…"
    return text


# ---------------------------------------------------------------------------
# HTTP client wrapper
# ---------------------------------------------------------------------------

class HttpClient:
    """
    Thin wrapper around requests.Session enforcing:
      - same-origin only fetches
      - rate limiting (configurable delay)
      - timeout handling
      - safe methods only unless explicitly told otherwise
    """

    SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}

    def __init__(self, base_url: str, timeout: float = 8.0, delay: float = 0.15,
                 verbose: bool = False):
        self.base_url = base_url
        parsed = urlparse(base_url)
        self.origin_scheme = parsed.scheme
        self.origin_host = parsed.netloc
        self.timeout = timeout
        self.delay = delay
        self.verbose = verbose
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": f"{SCANNER_NAME}/{SCANNER_VERSION} (authorized-assessment)"
        })
        self._last_request_time = 0.0
        self.request_count = 0

    def is_same_origin(self, url: str) -> bool:
        try:
            p = urlparse(url)
        except ValueError:
            return False
        if not p.netloc:
            return True  # relative URL
        return p.netloc == self.origin_host and p.scheme in ("http", "https")

    def _throttle(self) -> None:
        elapsed = time.time() - self._last_request_time
        if elapsed < self.delay:
            time.sleep(self.delay - elapsed)
        self._last_request_time = time.time()

    def request(self, method: str, url: str, allow_state_change: bool = False,
                **kwargs: Any) -> Optional[requests.Response]:
        """Perform a rate-limited, same-origin-checked HTTP request."""
        method = method.upper()
        if not self.is_same_origin(url):
            return None
        if method not in self.SAFE_METHODS and not allow_state_change:
            # Refuse to silently fire state-changing requests; callers must
            # opt in explicitly and only for scoped, harmless probes.
            return None

        self._throttle()
        kwargs.setdefault("timeout", self.timeout)
        kwargs.setdefault("allow_redirects", True)
        try:
            resp = self.session.request(method, url, **kwargs)
            self.request_count += 1
            if self.verbose:
                print(f"    [{method}] {url} -> {resp.status_code}")
            return resp
        except requests.RequestException as exc:
            if self.verbose:
                print(f"    [{method}] {url} -> ERROR ({exc})")
            return None

    def get(self, url: str, **kwargs: Any) -> Optional[requests.Response]:
        return self.request("GET", url, **kwargs)

    def new_session_client(self) -> "HttpClient":
        """Create a sibling client that shares config but has its own cookies."""
        clone = HttpClient(self.base_url, self.timeout, self.delay, self.verbose)
        return clone


# ---------------------------------------------------------------------------
# Crawler
# ---------------------------------------------------------------------------

LINK_ATTR_RE = re.compile(
    r'''(?:href|src|action)\s*=\s*["']([^"'#>\s]+)["']''', re.IGNORECASE
)
JS_STRING_ENDPOINT_RE = re.compile(
    r'''["'`](/(?:api|student|warden|grievance|grievances|attachment|attachments|comments?)[^"'`\s?]*)["'`]''',
    re.IGNORECASE,
)
FORM_RE = re.compile(r"<form\b[^>]*>(.*?)</form>", re.IGNORECASE | re.DOTALL)
FORM_OPEN_RE = re.compile(
    r'<form\b[^>]*\baction\s*=\s*["\']?([^"\'>\s]*)["\']?[^>]*'
    r'(?:\bmethod\s*=\s*["\']?(\w+)["\']?)?', re.IGNORECASE
)
INPUT_NAME_RE = re.compile(
    r'<input\b[^>]*\bname\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE
)
ID_LIKE_PARAM_RE = re.compile(
    r"\b(id|user_id|student_id|grievance_id|attachment_id|comment_id|warden_id)\b",
    re.IGNORECASE,
)
NUMERIC_PATH_SEGMENT_RE = re.compile(r"/(\d{1,10})(?:/|$)")

ROLE_HINT_PATTERNS = [
    (re.compile(r"/warden", re.IGNORECASE), "warden"),
    (re.compile(r"/admin", re.IGNORECASE), "warden"),
    (re.compile(r"/student", re.IGNORECASE), "student"),
]


class Crawler:
    """Same-origin, non-destructive crawler for HTML pages and JS-referenced
    API endpoints."""

    def __init__(self, client: HttpClient, max_pages: int = 60, verbose: bool = False):
        self.client = client
        self.max_pages = max_pages
        self.verbose = verbose
        self.visited: Set[str] = set()
        self.pages: Dict[str, requests.Response] = {}
        self.endpoints: Dict[str, EndpointInfo] = {}
        self.forms: List[Dict[str, Any]] = []

    @staticmethod
    def _normalize(url: str) -> str:
        p = urlsplit(url)
        # drop fragments; keep query since it may distinguish endpoints
        return p._replace(fragment="").geturl()

    def _role_hint(self, url: str) -> str:
        for pattern, role in ROLE_HINT_PATTERNS:
            if pattern.search(url):
                return role
        return "unknown"

    def _record_endpoint(self, url: str, kind: str, source: str, method: str = "GET",
                          params: Optional[List[str]] = None) -> None:
        norm = self._normalize(url)
        if norm not in self.endpoints:
            self.endpoints[norm] = EndpointInfo(
                url=norm, method=method, kind=kind,
                params=params or [], source=source,
                role_hint=self._role_hint(norm),
            )
        else:
            existing = self.endpoints[norm]
            for p in (params or []):
                if p not in existing.params:
                    existing.params.append(p)

    def _extract_links(self, base_url: str, body: str) -> List[str]:
        links = []
        for match in LINK_ATTR_RE.finditer(body):
            links.append(urljoin(base_url, match.group(1)))
        for match in JS_STRING_ENDPOINT_RE.finditer(body):
            links.append(urljoin(base_url, match.group(1)))
        return links

    def _extract_forms(self, base_url: str, body: str) -> None:
        for form_match in FORM_RE.finditer(body):
            form_html = form_match.group(0)
            inner = form_match.group(1)
            open_match = FORM_OPEN_RE.search(form_html)
            action = open_match.group(1) if open_match else ""
            method = (open_match.group(2) if open_match and open_match.group(2) else "GET").upper()
            action_url = urljoin(base_url, action) if action else base_url
            input_names = INPUT_NAME_RE.findall(inner)
            self.forms.append({
                "page": base_url,
                "action": self._normalize(action_url),
                "method": method,
                "fields": input_names,
                "has_password": bool(re.search(r'type=["\']password["\']', inner, re.IGNORECASE)),
            })
            self._record_endpoint(action_url, "form", "html", method=method, params=input_names)

    def crawl(self, start_url: str) -> None:
        queue: deque = deque([start_url])
        seen_queue: Set[str] = {self._normalize(start_url)}

        while queue and len(self.visited) < self.max_pages:
            url = queue.popleft()
            norm = self._normalize(url)
            if norm in self.visited:
                continue
            if not self.client.is_same_origin(url):
                continue

            resp = self.client.get(url)
            self.visited.add(norm)
            if resp is None:
                continue
            self.pages[norm] = resp
            self._record_endpoint(norm, "page", "crawl")

            content_type = resp.headers.get("Content-Type", "")
            if "html" not in content_type and "javascript" not in content_type and \
               "json" not in content_type and content_type != "":
                continue

            body = resp.text if resp.text else ""

            # query params on this page's own URL
            qs = parse_qs(urlparse(norm).query)
            if qs:
                self._record_endpoint(norm, "page", "crawl", params=list(qs.keys()))

            # numeric id-like path segments -> candidate object references
            if NUMERIC_PATH_SEGMENT_RE.search(norm):
                self._record_endpoint(norm, "object-ref", "crawl")

            if "html" in content_type or content_type == "":
                self._extract_forms(norm, body)

            for link in self._extract_links(norm, body):
                link_norm = self._normalize(link)
                if not self.client.is_same_origin(link_norm):
                    continue
                kind = "page"
                if re.search(r"/api/|\.json(?:$|\?)", link_norm, re.IGNORECASE):
                    kind = "api"
                elif re.search(r"/attachment", link_norm, re.IGNORECASE):
                    kind = "attachment"
                self._record_endpoint(link_norm, kind, "html" if "html" in content_type else "js")

                if link_norm not in seen_queue and len(self.visited) < self.max_pages:
                    seen_queue.add(link_norm)
                    queue.append(link_norm)

    def endpoints_by_kind(self, kind: str) -> List[EndpointInfo]:
        return [e for e in self.endpoints.values() if e.kind == kind]

    def id_like_endpoints(self) -> List[EndpointInfo]:
        out = []
        for e in self.endpoints.values():
            if NUMERIC_PATH_SEGMENT_RE.search(e.url) or any(
                ID_LIKE_PARAM_RE.search(p) for p in e.params
            ):
                out.append(e)
        return out


# ---------------------------------------------------------------------------
# Checker modules
# ---------------------------------------------------------------------------

SQL_ERROR_SIGNATURES = [
    "SQLSTATE", "you have an error in your sql syntax", "mysql_fetch",
    "mysqli", "postgresql", "pg_query", "sqlite3.OperationalError",
    "sqlite error", "ora-01", "ora-00", "odbc", "sql syntax", "database error",
    "query failed", "syntax error at or near", "unclosed quotation mark",
    "npgsql", "sqlstate[", "warning: mysql", "sqlserverexception",
]

FRAMEWORK_ERROR_SIGNATURES = [
    "traceback (most recent call last)", "at node_modules/", "internal server error",
    "unhandled exception", "stack trace", "debug = true", "django.db.utils",
    "prisma.", "typeorm", "sequelizeconnectionerror", "econnrefused",
    "cannot find module", "referenceerror", "typeerror:", "at eval (",
    "internal/modules", "vite:error", "sveltekit",
]

INTERNAL_PATH_RE = re.compile(
    r"(?:[A-Za-z]:\\\\[\w\\\\.]+|/(?:home|usr|var|etc|opt|srv)/[\w./-]+|node_modules[/\\][\w./-]+)"
)
INTERNAL_IP_RE = re.compile(
    r"\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|"
    r"172\.(?:1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}|127\.0\.0\.1)\b"
)

DANGEROUS_UPLOAD_EXTENSIONS = [
    ".php", ".phtml", ".jsp", ".asp", ".aspx", ".exe", ".sh", ".bat",
    ".cmd", ".js", ".py", ".rb", ".pl", ".cgi", ".dll", ".msi", ".htaccess",
]

SECURITY_HEADERS_SPEC = {
    "Content-Security-Policy": ("High", "Prevents/limits XSS and data-injection by restricting allowed content sources."),
    "Strict-Transport-Security": ("Medium", "Ensures browsers only connect over HTTPS, preventing downgrade/MITM."),
    "X-Content-Type-Options": ("Low", "Prevents MIME-sniffing that can turn a file upload into executable content."),
    "X-Frame-Options": ("Medium", "Mitigates clickjacking of Student/Warden actions."),
    "Referrer-Policy": ("Low", "Limits leakage of sensitive URLs (e.g. grievance IDs) via the Referer header."),
    "Permissions-Policy": ("Low", "Restricts access to sensitive browser features/APIs."),
}


class BaseChecker:
    def __init__(self, client: HttpClient, crawler: Crawler,
                 collector: FindingCollector, config: ScanConfig):
        self.client = client
        self.crawler = crawler
        self.collector = collector
        self.config = config

    def log(self, msg: str) -> None:
        if self.config.verbose:
            print(f"    {msg}")


class HeaderChecker(BaseChecker):
    """Checks security response headers across discovered pages."""

    def run(self) -> None:
        sampled = list(self.crawler.pages.items())[:15] or self._fetch_root()
        missing_tracker: Dict[str, List[str]] = {h: [] for h in SECURITY_HEADERS_SPEC}

        for url, resp in sampled:
            headers = resp.headers
            for header_name in SECURITY_HEADERS_SPEC:
                if header_name not in headers:
                    missing_tracker[header_name].append(url)

            server_hdr = headers.get("Server", "")
            if server_hdr and re.search(r"\d+\.\d+", server_hdr):
                self.collector.add(
                    title="Server Version Disclosure",
                    severity="Low", confidence="High", status="Confirmed",
                    category="Security Misconfiguration", url=url,
                    affected_component="HTTP Server",
                    attack_path="Attacker -> HTTP response headers",
                    trust_boundary="Public internet -> Web server",
                    blast_radius="Application-wide",
                    description="The Server header discloses specific software/version information.",
                    evidence=f"Server: {redact(server_hdr, keep=len(server_hdr))}",
                    impact="Version fingerprinting can help an attacker target known CVEs for that version.",
                    recommendation="Suppress or generalize the Server header at the reverse proxy/server config level.",
                    verification="Re-request the page and inspect the Server response header.",
                    residual_risk="Low if patching remains current regardless of banner visibility.",
                )

        for header_name, urls in missing_tracker.items():
            if not urls:
                continue
            severity, rationale = SECURITY_HEADERS_SPEC[header_name]
            example_urls = ", ".join(urls[:3])
            self.collector.add(
                title=f"Missing {header_name} Header",
                severity=severity, confidence="High", status="Confirmed",
                category="Missing Security Headers",
                url=example_urls,
                affected_component="HTTP response headers (application-wide)",
                attack_path="Attacker -> Browser rendering HostelGrievance responses",
                trust_boundary="Server response -> Browser",
                blast_radius="Application-wide",
                description=f"The '{header_name}' header was not present on {len(urls)} of "
                            f"{len(sampled)} sampled responses.",
                evidence=f"Missing on: {example_urls}"
                         + (f" (+{len(urls) - 3} more)" if len(urls) > 3 else ""),
                impact=rationale,
                recommendation=f"Set the '{header_name}' header on all HTTP responses, "
                                f"typically via reverse proxy or a global middleware.",
                verification="Re-request the listed URLs and confirm the header is present.",
                residual_risk="Low once consistently applied application-wide.",
            )

    def _fetch_root(self) -> List[Tuple[str, requests.Response]]:
        resp = self.client.get(self.client.base_url)
        return [(self.client.base_url, resp)] if resp is not None else []


class CookieChecker(BaseChecker):
    """Checks session/cookie security attributes."""

    SENSITIVE_COOKIE_NAME_RE = re.compile(
        r"session|token|auth|jwt|sid|remember", re.IGNORECASE
    )

    def run(self) -> None:
        seen_cookies: Set[str] = set()
        for url, resp in list(self.crawler.pages.items())[:20]:
            for cookie in resp.cookies:
                if cookie.name in seen_cookies:
                    continue
                seen_cookies.add(cookie.name)
                is_sensitive = bool(self.SENSITIVE_COOKIE_NAME_RE.search(cookie.name))

                secure = bool(cookie.secure)
                httponly = "httponly" in [k.lower() for k in (cookie._rest or {}).keys()]
                samesite = None
                for k, v in (cookie._rest or {}).items():
                    if k.lower() == "samesite":
                        samesite = v

                if is_sensitive and not httponly:
                    self.collector.add(
                        title=f"Session Cookie Missing HttpOnly ({cookie.name})",
                        severity="Medium", confidence="High", status="Confirmed",
                        category="Session/Cookie Weakness", url=url,
                        affected_component="Session cookie",
                        attack_path="Reflected/Stored XSS -> document.cookie -> session theft",
                        trust_boundary="Client-side script -> Cookie store",
                        blast_radius="Single User",
                        description=f"Cookie '{cookie.name}' does not set the HttpOnly flag.",
                        evidence=f"Cookie name: {cookie.name} (value redacted)",
                        impact="If any XSS exists, session cookies without HttpOnly can be stolen via JavaScript.",
                        recommendation="Set HttpOnly on all authentication/session cookies.",
                        verification="Inspect Set-Cookie headers for the HttpOnly attribute.",
                        residual_risk="Low if combined with a strong CSP preventing script injection.",
                    )

                if is_sensitive and not secure and self.client.origin_scheme == "https":
                    self.collector.add(
                        title=f"Session Cookie Missing Secure Flag ({cookie.name})",
                        severity="Medium", confidence="High", status="Confirmed",
                        category="Session/Cookie Weakness", url=url,
                        affected_component="Session cookie",
                        attack_path="Network attacker on shared network -> cookie sent over HTTP",
                        trust_boundary="Network transport",
                        blast_radius="Single User",
                        description=f"Cookie '{cookie.name}' does not set the Secure flag on an HTTPS origin.",
                        evidence=f"Cookie name: {cookie.name} (value redacted)",
                        impact="The cookie could be transmitted over an unencrypted channel if the app is ever reached via HTTP.",
                        recommendation="Set the Secure flag on all session/auth cookies.",
                        verification="Inspect Set-Cookie headers for the Secure attribute.",
                        residual_risk="Low once HSTS and Secure are both enforced.",
                    )

                if is_sensitive and (samesite is None or samesite.lower() not in ("lax", "strict")):
                    self.collector.add(
                        title=f"Weak or Missing SameSite Attribute ({cookie.name})",
                        severity="Medium", confidence="Medium", status="Confirmed",
                        category="Session/Cookie Weakness", url=url,
                        affected_component="Session cookie",
                        attack_path="Cross-site request -> forged state-changing action (CSRF)",
                        trust_boundary="Cross-origin request -> Session cookie",
                        blast_radius="Single User",
                        description=f"Cookie '{cookie.name}' has SameSite={samesite!r}, which does not "
                                    f"restrict cross-site sending.",
                        evidence=f"Cookie name: {cookie.name}, SameSite={samesite}",
                        impact="Weak SameSite settings increase CSRF exposure for state-changing "
                               "grievance/warden actions.",
                        recommendation="Set SameSite=Lax (or Strict where feasible) on session cookies, "
                                       "and use CSRF tokens for state-changing requests.",
                        verification="Inspect Set-Cookie headers for the SameSite attribute.",
                        residual_risk="Low once paired with anti-CSRF tokens on POST/PUT/DELETE.",
                    )

        # tokens exposed in URLs
        for url in list(self.crawler.endpoints.keys())[: self.config.max_pages]:
            qs = parse_qs(urlparse(url).query)
            for key in qs:
                if re.search(r"token|session|auth|jwt", key, re.IGNORECASE):
                    self.collector.add(
                        title="Potential Session/Auth Token Exposed in URL",
                        severity="Medium", confidence="Low", status="Potential",
                        category="Session/Cookie Weakness", url=url,
                        affected_component="URL query string",
                        attack_path="Token in URL -> browser history/proxy/referrer logs -> leakage",
                        trust_boundary="Client -> Logs/Referrer",
                        blast_radius="Single User",
                        description=f"A parameter named '{key}' suggestive of a session/auth token "
                                     "appears in a URL.",
                        evidence=f"Parameter name observed: {key}",
                        impact="URL-embedded tokens can leak via browser history, proxies, and Referer headers.",
                        recommendation="Pass session/auth tokens via cookies or Authorization headers, not URLs.",
                        verification="Manually confirm whether the parameter carries a live session token.",
                        residual_risk="Depends on actual parameter content; verify manually.",
                    )


class AuthChecker(BaseChecker):
    """Checks authentication-related weaknesses without brute forcing."""

    PROTECTED_HINT_RE = re.compile(
        r"/student|/warden|/grievance|/profile|/account|/dashboard", re.IGNORECASE
    )

    def run(self) -> None:
        for url, resp in self.crawler.pages.items():
            if not self.PROTECTED_HINT_RE.search(url):
                continue
            if resp.status_code == 200 and self._looks_authenticated_content(resp):
                self.collector.add(
                    title="Potentially Protected Page Accessible Without Authentication",
                    severity="High", confidence="Medium", status="Potential",
                    category="Broken Authentication", url=url,
                    affected_component="Route/session middleware",
                    attack_path="Unauthenticated attacker -> direct URL request -> protected content",
                    trust_boundary="Anonymous -> Authenticated area",
                    blast_radius="Multiple Users",
                    description="A URL pattern suggestive of authenticated Student/Warden "
                                 "functionality returned HTTP 200 with no active login session "
                                 "in this scanner's session.",
                    evidence=f"GET {url} -> {resp.status_code}, "
                             f"{truncate(resp.text, 160)}",
                    impact="If truly unauthenticated, this could expose grievance data or "
                           "warden functionality to anyone.",
                    recommendation="Enforce server-side session/authentication checks on this "
                                   "route before rendering any protected data.",
                    verification="Manually confirm with a browser in a private/incognito session "
                                 "(no cookies) whether the page renders protected content or "
                                 "redirects to login.",
                    residual_risk="Depends on manual verification; classified as Potential "
                                   "because client-side redirects cannot be distinguished from "
                                   "true 200 responses by this scanner alone.",
                )

        # password forms over HTTP
        for form in self.crawler.forms:
            if form["has_password"] and urlparse(form["action"]).scheme == "http":
                self.collector.add(
                    title="Password Form Submits Over HTTP",
                    severity="Critical", confidence="High", status="Confirmed",
                    category="Broken Authentication", url=form["action"],
                    affected_component="Login/authentication form",
                    attack_path="Network attacker (MITM) -> cleartext credential capture",
                    trust_boundary="Network transport",
                    blast_radius="Application-wide",
                    description="A form containing a password field submits to an HTTP "
                                 "(non-TLS) action URL.",
                    evidence=f"Form action: {form['action']}, method: {form['method']}",
                    impact="Credentials could be intercepted in transit by a network attacker.",
                    recommendation="Serve the entire application over HTTPS and redirect all "
                                   "HTTP traffic to HTTPS.",
                    verification="Submit the form and confirm the request is sent over HTTP "
                                 "using browser dev tools.",
                    residual_risk="None once HTTPS is enforced end-to-end with HSTS.",
                )

        # logout indicator check
        logout_like = [u for u in self.crawler.endpoints if re.search(r"logout|signout", u, re.IGNORECASE)]
        if not logout_like:
            self.collector.add(
                title="No Logout/Session-Invalidation Endpoint Observed",
                severity="Low", confidence="Low", status="Manual Verification Required",
                category="Broken Authentication", url=self.client.base_url,
                affected_component="Session lifecycle",
                attack_path="Shared/public device -> session persists after user leaves",
                trust_boundary="Session lifecycle boundary",
                blast_radius="Single User",
                description="The crawler did not discover any link or form referencing "
                             "logout/sign-out functionality.",
                evidence=f"Pages crawled: {len(self.crawler.visited)}; no logout-like URL found.",
                impact="If logout does not properly invalidate the server-side session, "
                       "stolen or shared cookies remain valid indefinitely.",
                recommendation="Confirm a logout mechanism exists and that it invalidates the "
                               "session server-side (not just clearing the client cookie).",
                verification="Manually log in, log out, and replay the old session cookie "
                             "against a protected endpoint to confirm it is rejected.",
                residual_risk="Unknown until manually verified.",
            )

    @staticmethod
    def _looks_authenticated_content(resp: requests.Response) -> bool:
        text = resp.text.lower() if resp.text else ""
        # heuristic: page contains data-table-like structures or explicit
        # role/grievance markers rather than a login prompt
        if "login" in text and "password" in text and len(text) < 4000:
            return False
        markers = ["grievance", "warden", "student id", "logout", "my grievances"]
        return any(m in text for m in markers)


class AccessControlChecker(BaseChecker):
    """
    IDOR/BOLA and vertical privilege-escalation checks. This is the highest
    priority module for HostelGrievance.

    Without authorized multi-account credentials, object references are
    reported as 'Authorization Test Candidate' rather than confirmed IDOR,
    per the requirement to avoid false positives.
    """

    def __init__(self, *args, sessions: Optional[Dict[str, HttpClient]] = None, **kwargs):
        super().__init__(*args, **kwargs)
        self.sessions = sessions or {}  # role name -> authenticated HttpClient

    def run(self) -> None:
        id_endpoints = self.crawler.id_like_endpoints()

        if len(self.sessions) < 2:
            self._report_candidates(id_endpoints)
        else:
            self._compare_sessions(id_endpoints)

        self._check_privileged_endpoints()

    def _report_candidates(self, id_endpoints: List[EndpointInfo]) -> None:
        grouped: Dict[str, List[str]] = {}
        for e in id_endpoints:
            base_pattern = NUMERIC_PATH_SEGMENT_RE.sub("/{id}/", e.url)
            grouped.setdefault(base_pattern, []).append(e.url)

        for pattern, urls in grouped.items():
            sensitive = bool(re.search(r"grievance|attachment|student|comment|warden", pattern, re.IGNORECASE))
            self.collector.add(
                title="Authorization Test Candidate: Direct Object Reference",
                severity="Medium" if sensitive else "Low",
                confidence="Low", status="Potential",
                category="IDOR/BOLA",
                url=urls[0],
                affected_component="Object-level authorization boundary",
                attack_path="Authenticated user A -> modify object ID -> access user B's object",
                trust_boundary="Owner user -> Other user's data",
                blast_radius="Multiple Users" if sensitive else "Single Resource",
                description=f"Endpoint pattern '{pattern}' uses a numeric/sequential "
                             f"identifier that may reference {'sensitive student/grievance ' if sensitive else ''}"
                             f"data belonging to a specific user. No second authorized "
                             f"account was supplied, so ownership enforcement could not be tested.",
                evidence=f"Example URL(s): {', '.join(urls[:3])}"
                         + (f" (+{len(urls) - 3} more)" if len(urls) > 3 else ""),
                impact="If server-side ownership checks are missing, an authenticated "
                       "Student could read or modify another Student's grievance, "
                       "comments, or attachments by changing the ID.",
                recommendation="Supply authorized test credentials for at least two "
                               "Student accounts (and a Warden account) via --credentials "
                               "so the scanner can safely compare access, or manually verify "
                               "that every object lookup checks 'does this ID belong to the "
                               "requesting session's user?' server-side.",
                verification="Log in as Student A, note an object ID belonging to Student B "
                             "(e.g. from a Warden view), and confirm Student A's session is "
                             "denied (403/404) when requesting it directly.",
                residual_risk="Unknown until authorized cross-account verification is performed.",
            )

    def _compare_sessions(self, id_endpoints: List[EndpointInfo]) -> None:
        role_names = list(self.sessions.keys())
        # Only test true read access; never mutate.
        for e in id_endpoints:
            if e.method != "GET":
                continue
            results: Dict[str, Optional[int]] = {}
            for role, client in self.sessions.items():
                resp = client.get(e.url)
                results[role] = resp.status_code if resp is not None else None
            self._evaluate_cross_access(e.url, results)

    def _evaluate_cross_access(self, url: str, results: Dict[str, Optional[int]]) -> None:
        allowed_roles = [r for r, code in results.items() if code and code < 400]
        if len(allowed_roles) <= 1:
            return  # looks correctly scoped, or nobody could access it

        # heuristic: if a URL is student-owned (contains 'student' or a
        # grievance path) and a *different* student session or the warden
        # session that shouldn't own it can also read it, flag it.
        is_student_pair = {"student_a", "student_b"}.issubset(set(allowed_roles))
        is_warden_over_student = "warden" in allowed_roles and any(
            r.startswith("student") for r in allowed_roles
        )

        if is_student_pair:
            self.collector.add(
                title="Confirmed Cross-User Access to Object (Potential IDOR)",
                severity="High", confidence="High", status="Confirmed",
                category="IDOR/BOLA", url=url,
                affected_component="Object-level authorization boundary",
                attack_path="Student A session -> request object -> object also readable by Student B session",
                trust_boundary="Student A -> Student B data",
                blast_radius="Multiple Users",
                description="Two independent, authorized Student sessions could both "
                             "successfully retrieve the same object-referenced resource.",
                evidence=f"HTTP status by role: {results}",
                impact="An authenticated Student can access another Student's grievance, "
                       "comment, or attachment data by requesting the object directly.",
                recommendation="Add a server-side ownership check on this endpoint: verify "
                               "the object's owner_id matches the session's user_id (or that "
                               "the session has an explicit Warden/staff role) before returning data.",
                verification="Confirmed via authorized two-account comparison during this scan.",
                residual_risk="Remains High until server-side ownership enforcement is added.",
            )
        elif is_warden_over_student and re.search(r"/warden", url, re.IGNORECASE) is None:
            # warden accessing a student-scoped URL is expected in this app
            # (wardens review grievances) so we do NOT flag this by default;
            # only non-warden-role-appropriate access patterns are notable.
            pass

    def _check_privileged_endpoints(self) -> None:
        privileged_patterns = [
            r"/admin", r"/api/admin", r"/api/warden", r"/warden",
            r"/status/update", r"/grievance/approve", r"/grievance/reject",
        ]
        candidates = [
            e for e in self.crawler.endpoints.values()
            if any(re.search(p, e.url, re.IGNORECASE) for p in privileged_patterns)
        ]
        if not candidates:
            return

        non_privileged_sessions = {
            r: c for r, c in self.sessions.items() if not r.startswith("warden") and not r.startswith("admin")
        }

        for e in candidates:
            if not non_privileged_sessions:
                self.collector.add(
                    title="Privileged Endpoint Discovered (Untested)",
                    severity="Info", confidence="Low", status="Manual Verification Required",
                    category="Privilege Escalation", url=e.url,
                    affected_component="Role-based access control",
                    attack_path="Student session -> request Warden/admin endpoint",
                    trust_boundary="Student role -> Warden role",
                    blast_radius="Role-wide",
                    description="A URL pattern suggestive of Warden/admin-only functionality "
                                 "was discovered by the crawler.",
                    evidence=f"URL: {e.url}",
                    impact="If role checks are missing, a Student account could perform "
                           "Warden-level actions (e.g. approving/rejecting grievances).",
                    recommendation="Supply an authorized non-Warden (Student) test account via "
                                   "--credentials so the scanner can safely verify this endpoint "
                                   "rejects non-Warden sessions, or verify manually.",
                    verification="Log in as a Student and confirm this endpoint returns "
                                 "403/redirect rather than privileged content or accepting the action.",
                    residual_risk="Unknown until authorized verification is performed.",
                )
                continue

            for role, client in non_privileged_sessions.items():
                resp = client.get(e.url)
                if resp is not None and resp.status_code < 400 and \
                   not re.search(r"login|sign in|unauthorized|forbidden", resp.text[:2000], re.IGNORECASE):
                    self.collector.add(
                        title="Potential Vertical Privilege Escalation",
                        severity="Critical", confidence="Medium", status="Confirmed",
                        category="Privilege Escalation", url=e.url,
                        affected_component="Role-based access control",
                        attack_path=f"{role} session -> Warden/admin endpoint -> "
                                     f"HTTP {resp.status_code} without role rejection",
                        trust_boundary=f"{role} role -> Warden role",
                        blast_radius="Role-wide",
                        description=f"A non-Warden session ('{role}') received a non-error "
                                     f"response from a Warden/admin-pattern endpoint.",
                        evidence=f"GET {e.url} as '{role}' -> {resp.status_code}, "
                                 f"body sample: {truncate(resp.text, 160)}",
                        impact="A Student-level account may be able to view or perform "
                               "Warden-only actions such as reviewing or updating grievance status.",
                        recommendation="Enforce server-side role checks (not just hidden UI "
                                       "elements) on every Warden/admin route and API handler.",
                        verification="Manually confirm the response body/action outcome; "
                                     "this scanner did not submit any state-changing request.",
                        residual_risk="Remains Critical until server-side role enforcement is added.",
                    )


class InputChecker(BaseChecker):
    """Reflected/HTML-injection/path-traversal indicator checks on safe GET params."""

    TRAVERSAL_PROBE = "../../../../etc/passwd"
    TRAVERSAL_SIGNATURE_RE = re.compile(r"root:.*:0:0:|\[boot loader\]", re.IGNORECASE)

    def run(self) -> None:
        tested = 0
        for e in list(self.crawler.endpoints.values()):
            if tested >= 25:
                break
            if e.method != "GET" or not e.params:
                continue
            parsed = urlparse(e.url)
            base_qs = parse_qs(parsed.query)
            for param in e.params:
                if tested >= 25:
                    break
                tested += 1
                self._probe_reflection(e.url, parsed, base_qs, param)
                self._probe_traversal(e.url, parsed, base_qs, param)

    def _probe_reflection(self, url: str, parsed, base_qs: Dict[str, List[str]], param: str) -> None:
        canary = f"HGSEC_{uuid.uuid4().hex[:8]}"
        qs = {k: v[:] for k, v in base_qs.items()}
        qs[param] = [canary]
        probe_url = parsed._replace(query=urlencode(qs, doseq=True)).geturl()
        resp = self.client.get(probe_url)
        if resp is None or canary not in (resp.text or ""):
            return

        context = "plain text"
        text = resp.text
        idx = text.find(canary)
        window = text[max(0, idx - 40): idx + len(canary) + 40]
        if re.search(r"<script[^>]*>[^<]*" + re.escape(canary), text, re.IGNORECASE):
            context = "JavaScript"
        elif re.search(r'=["\'][^"\']*' + re.escape(canary), window):
            context = "attribute"
        elif re.search(r"<[^>]*" + re.escape(canary), window):
            context = "HTML tag"

        self.collector.add(
            title=f"Reflected Input Without Apparent Encoding ({param})",
            severity="Medium", confidence="Low", status="Potential",
            category="Unsafe Input Handling", url=probe_url,
            affected_component=f"Parameter '{param}'",
            attack_path="Attacker-crafted link -> parameter reflected in response -> browser renders it",
            trust_boundary="User input -> HTML response",
            blast_radius="Single User",
            description=f"A harmless canary value placed in parameter '{param}' was reflected "
                         f"back in the response, in {context} context.",
            evidence=f"Canary '{canary}' found in response near: …{truncate(window, 120)}…",
            impact="If this context lacks proper output encoding, it may allow injection of "
                   "HTML/JavaScript (reflected XSS) depending on how the value is rendered.",
            recommendation="Ensure output encoding appropriate to the render context "
                           "(HTML-entity encode for HTML body, attribute-encode for attributes, "
                           "JS-string-escape for script context).",
            verification="This is a reflection indicator only; the --xss check performs "
                         "additional context-aware analysis. Manually confirm exploitability.",
            residual_risk="Depends on encoding used; verify manually before deprioritizing.",
        )

    def _probe_traversal(self, url: str, parsed, base_qs: Dict[str, List[str]], param: str) -> None:
        if not re.search(r"file|path|name|attachment|doc|download", param, re.IGNORECASE):
            return
        qs = {k: v[:] for k, v in base_qs.items()}
        qs[param] = [self.TRAVERSAL_PROBE]
        probe_url = parsed._replace(query=urlencode(qs, doseq=True)).geturl()
        resp = self.client.get(probe_url)
        if resp is None:
            return
        if self.TRAVERSAL_SIGNATURE_RE.search(resp.text or ""):
            self.collector.add(
                title=f"Potential Path Traversal via Parameter '{param}'",
                severity="High", confidence="Medium", status="Potential",
                category="Unsafe Input Handling", url=probe_url,
                affected_component=f"File-handling parameter '{param}'",
                attack_path="Attacker -> traversal sequence in file parameter -> filesystem read",
                trust_boundary="User input -> Server filesystem",
                blast_radius="Application-wide",
                description=f"A path traversal probe in parameter '{param}' returned content "
                             f"matching a known sensitive-file signature.",
                evidence="Response matched a filesystem-content signature (redacted).",
                impact="An attacker may be able to read arbitrary files from the server "
                       "filesystem, including configuration/secrets.",
                recommendation="Validate and sanitize file-path parameters; resolve against an "
                               "allow-list of known attachment IDs rather than raw filenames/paths.",
                verification="Manually confirm the response content in a controlled test.",
                residual_risk="High until input is fully constrained to an allow-list.",
            )


class XssChecker(BaseChecker):
    """Dedicated, context-aware safe XSS canary check, including a stored-XSS
    heuristic across previously-seen forms (read-only observation of results
    already rendered by the app; does not submit forms by default)."""

    def run(self) -> None:
        canary = f"SECURITY_SCANNER_XSS_{uuid.uuid4().hex[:8]}"
        for e in list(self.crawler.endpoints.values())[: self.config.max_pages]:
            if e.method != "GET" or not e.params:
                continue
            parsed = urlparse(e.url)
            qs = parse_qs(parsed.query)
            for param in list(qs.keys())[:2]:
                test_qs = {k: v[:] for k, v in qs.items()}
                test_qs[param] = [f"<{canary}>"]
                probe_url = parsed._replace(query=urlencode(test_qs, doseq=True)).geturl()
                resp = self.client.get(probe_url)
                if resp is None:
                    continue
                text = resp.text or ""
                raw_tag_present = f"<{canary}>" in text
                escaped_present = html.escape(f"<{canary}>") in text or \
                    f"&lt;{canary}&gt;" in text

                if raw_tag_present:
                    self.collector.add(
                        title=f"Potential Reflected XSS in Parameter '{param}'",
                        severity="High", confidence="Medium", status="Potential",
                        category="XSS", url=probe_url,
                        affected_component=f"Parameter '{param}'",
                        attack_path="Attacker-crafted link with script-like payload -> "
                                     "unescaped reflection -> victim's browser executes it",
                        trust_boundary="User input -> Rendered HTML",
                        blast_radius="Single User",
                        description="A harmless HTML-tag-shaped canary was reflected in the "
                                     "response WITHOUT HTML-entity encoding.",
                        evidence=f"Unescaped '<{canary}>' observed in response.",
                        impact="A real payload in this position could execute arbitrary "
                               "JavaScript in a victim's session (e.g. a Student or Warden), "
                               "potentially leading to session/token theft.",
                        recommendation="HTML-entity encode all user-controlled output rendered "
                                       "into HTML context; prefer a templating engine with "
                                       "autoescaping enabled by default.",
                        verification="This finding is based on a non-executing canary string, "
                                     "not a confirmed JavaScript execution. Manually confirm "
                                     "impact in a browser before treating as fully confirmed.",
                        residual_risk="High until output encoding is verified and enforced.",
                    )
                elif escaped_present:
                    self.log(f"Canary escaped correctly for param '{param}' at {e.url}")

        self._check_stored_indicators()

    def _check_stored_indicators(self) -> None:
        """
        Look for prior scanner canaries appearing on OTHER pages than where
        they were submitted, which would indicate stored/persisted
        unescaped input. This is purely observational over already-crawled
        pages; the scanner does not submit grievance/comment forms itself.
        """
        canary_pattern = re.compile(r"SECURITY_SCANNER_XSS_[0-9a-f]{8}")
        seen: Dict[str, str] = {}
        for url, resp in self.crawler.pages.items():
            for m in canary_pattern.finditer(resp.text or ""):
                seen.setdefault(m.group(0), url)
        # Note: without submitting forms, this will typically find nothing
        # on a fresh scan; retained for scans run against a target where
        # grievance/comment content already includes test canaries.
        if len(seen) > 0:
            for canary, url in seen.items():
                self.collector.add(
                    title="Stored Canary Observed in Rendered Content",
                    severity="Medium", confidence="Low", status="Manual Verification Required",
                    category="XSS", url=url,
                    affected_component="Stored grievance/comment content",
                    attack_path="Stored input -> rendered on another page -> potential stored XSS",
                    trust_boundary="Stored data -> Rendered HTML",
                    blast_radius="Multiple Users",
                    description="A scanner canary value was found rendered in page content, "
                                 "suggesting stored input is echoed elsewhere in the app.",
                    evidence=f"Canary observed at: {url}",
                    impact="If the original submission point does not encode output, this "
                           "could indicate a stored XSS affecting any user who views the "
                           "grievance/comment thread.",
                    recommendation="Verify the originating input field HTML-encodes stored "
                                   "content on every page where it is rendered.",
                    verification="Manually trace the canary back to its submission form and "
                                 "confirm encoding behavior.",
                    residual_risk="Unknown until manually traced.",
                )


class SqliChecker(BaseChecker):
    """Conservative, non-destructive SQL-error-signature probing."""

    PROBES = ["'", "''", "' OR '1'='1", '"', "1'"]

    def run(self) -> None:
        tested = 0
        for e in list(self.crawler.endpoints.values()):
            if tested >= 20:
                break
            if e.method != "GET" or not e.params:
                continue
            parsed = urlparse(e.url)
            base_qs = parse_qs(parsed.query)
            for param in e.params:
                if tested >= 20:
                    break
                tested += 1
                baseline = self.client.get(e.url)
                baseline_len = len(baseline.text) if baseline is not None and baseline.text else None

                for probe in self.PROBES:
                    qs = {k: v[:] for k, v in base_qs.items()}
                    qs[param] = [probe]
                    probe_url = parsed._replace(query=urlencode(qs, doseq=True)).geturl()
                    resp = self.client.get(probe_url)
                    if resp is None:
                        continue
                    text_lower = (resp.text or "").lower()
                    matched_sig = next((sig for sig in SQL_ERROR_SIGNATURES if sig.lower() in text_lower), None)
                    if matched_sig:
                        self.collector.add(
                            title=f"Potential SQL Injection Indicator in Parameter '{param}'",
                            severity="High", confidence="Medium", status="Potential",
                            category="SQL Injection", url=probe_url,
                            affected_component=f"Parameter '{param}' / database query layer",
                            attack_path="Attacker -> crafted SQL metacharacter in parameter -> "
                                         "database error surfaced in response",
                            trust_boundary="User input -> Database query construction",
                            blast_radius="Application-wide",
                            description=f"Submitting a SQL metacharacter probe in parameter "
                                         f"'{param}' produced a response containing a database "
                                         f"error signature ('{matched_sig}').",
                            evidence=f"Probe: {redact(probe, keep=len(probe))} -> matched signature '{matched_sig}'",
                            impact="Database error leakage often indicates unsanitized input "
                                   "reaching a SQL query, which could allow data extraction or "
                                   "manipulation with a more advanced payload.",
                            recommendation="Use parameterized queries / prepared statements "
                                           "(or the ORM's safe query builder) for all "
                                           "user-controlled input; never concatenate input into SQL.",
                            verification="No data was extracted or modified. Manually verify "
                                         "using authorized, controlled testing only.",
                            residual_risk="High until parameterized queries are confirmed "
                                         "for this code path.",
                        )
                        break  # one signature per param is enough evidence

                    if baseline_len is not None and resp.text and \
                       abs(len(resp.text) - baseline_len) > max(500, baseline_len * 0.5) and \
                       resp.status_code != (baseline.status_code if baseline else None):
                        self.collector.add(
                            title=f"Anomalous Response to SQL Probe in Parameter '{param}'",
                            severity="Low", confidence="Low", status="Manual Verification Required",
                            category="SQL Injection", url=probe_url,
                            affected_component=f"Parameter '{param}'",
                            attack_path="Attacker -> SQL metacharacter -> anomalous server behavior",
                            trust_boundary="User input -> Database query construction",
                            blast_radius="Unknown",
                            description="A SQL metacharacter probe produced a response "
                                         "significantly different in size/status from baseline, "
                                         "without a recognizable error signature.",
                            evidence=f"Baseline status/len vs probe status/len: "
                                     f"{baseline.status_code if baseline else '?'}/{baseline_len} vs "
                                     f"{resp.status_code}/{len(resp.text)}",
                            impact="Inconclusive; could indicate query interference or be unrelated.",
                            recommendation="Manually investigate this parameter's query handling.",
                            verification="Requires manual, authorized follow-up testing.",
                            residual_risk="Unknown.",
                        )


class FileSecurityChecker(BaseChecker):
    """
    High-priority module: attachment/upload/download security for
    HostelGrievance. Never uploads dangerous files; only enabled to send a
    single harmless text file if --enable-upload-probe is explicitly set.
    """

    def run(self) -> None:
        attachment_endpoints = [
            e for e in self.crawler.endpoints.values()
            if e.kind == "attachment" or re.search(r"attachment", e.url, re.IGNORECASE)
        ]
        upload_forms = [f for f in self.crawler.forms if re.search(
            r"attachment|upload|file", f["action"] + " ".join(f["fields"]), re.IGNORECASE)]

        self._check_download_auth(attachment_endpoints)
        self._check_upload_forms(upload_forms)
        self._check_direct_object_attachments(attachment_endpoints)

    def _check_download_auth(self, endpoints: List[EndpointInfo]) -> None:
        anon_client = self.client.new_session_client()
        for e in endpoints:
            resp = anon_client.get(e.url)
            if resp is None:
                continue
            content_type = resp.headers.get("Content-Type", "")
            looks_like_file = resp.status_code == 200 and (
                "html" not in content_type or "attachment" in resp.headers.get("Content-Disposition", "")
            )
            if looks_like_file:
                self.collector.add(
                    title="Attachment Possibly Downloadable Without Authorization",
                    severity="High", confidence="Medium", status="Potential",
                    category="Unsafe File Upload/Download", url=e.url,
                    affected_component="Attachment download endpoint",
                    attack_path="Unauthenticated/unauthorized request -> direct attachment fetch -> file returned",
                    trust_boundary="Anonymous or wrong-owner session -> Attachment storage",
                    blast_radius="Multiple Users",
                    description="A fresh, unauthenticated scanner session received a non-HTML, "
                                 "200-status response from an attachment endpoint.",
                    evidence=f"GET {e.url} -> {resp.status_code}, "
                             f"Content-Type: {content_type}, "
                             f"Content-Disposition: {resp.headers.get('Content-Disposition', '')}",
                    impact="Grievance attachments (potentially containing sensitive student "
                           "information) may be retrievable without proper authentication or "
                           "ownership checks.",
                    recommendation="Require authentication for all attachment routes and verify "
                                   "the requesting user owns the grievance (or is a Warden) "
                                   "before streaming file content.",
                    verification="Manually confirm using a clean browser session with no "
                                 "cookies whether the file downloads.",
                    residual_risk="High until server-side ownership + auth checks are confirmed.",
                )

    def _check_upload_forms(self, forms: List[Dict[str, Any]]) -> None:
        for form in forms:
            has_file_field_marker = any(
                re.search(r"file|attachment|upload", f, re.IGNORECASE) for f in form["fields"]
            ) or True  # form matched by regex already implies file-related
            action_is_https = urlparse(form["action"]).scheme == "https"

            self.collector.add(
                title="Attachment Upload Form Discovered — Review Server-Side Validation",
                severity="Info", confidence="High", status="Informational",
                category="Unsafe File Upload/Download", url=form["action"],
                affected_component="Attachment upload endpoint",
                attack_path="Authenticated user -> upload -> stored/served attachment",
                trust_boundary="User-supplied file -> Application storage",
                blast_radius="Unknown",
                description="An upload form was discovered. This scanner does not upload "
                             "files by default; server-side validation must be reviewed "
                             "manually or with an explicit, harmless probe file.",
                evidence=f"Form action: {form['action']}, method: {form['method']}, "
                         f"fields: {form['fields']}",
                impact="Missing extension/content-type allow-listing, missing size limits, or "
                       "serving uploads from an executable path could allow malicious file "
                       "upload leading to stored XSS or remote code execution.",
                recommendation="Enforce an extension AND content-type allow-list (not a "
                               "deny-list), re-encode/re-validate file contents server-side, "
                               "store uploads outside the web root or with forced "
                               "Content-Disposition/Content-Type on download, apply size "
                               "limits, and scan for dangerous extensions: "
                               + ", ".join(DANGEROUS_UPLOAD_EXTENSIONS[:6]) + ", etc.",
                verification="Manually attempt an authorized upload of a harmless test file "
                             "with an unexpected extension to confirm rejection behavior, "
                             "or re-run with --enable-upload-probe against an authorized "
                             "test account.",
                residual_risk="Unknown until manual/authorized upload validation testing.",
            )

            if not action_is_https and self.client.origin_scheme == "https":
                self.collector.add(
                    title="Upload Form Action Not HTTPS",
                    severity="Medium", confidence="High", status="Confirmed",
                    category="Unsafe File Upload/Download", url=form["action"],
                    affected_component="Attachment upload endpoint",
                    attack_path="Network attacker -> intercept file upload in transit",
                    trust_boundary="Network transport",
                    blast_radius="Single User",
                    description="An upload form's action URL is not HTTPS while the main "
                                 "application is served over HTTPS.",
                    evidence=f"Form action: {form['action']}",
                    impact="Uploaded file contents (potentially sensitive) could be exposed "
                           "in transit.",
                    recommendation="Serve all form actions, especially file uploads, over HTTPS.",
                    verification="Inspect the rendered form's action attribute in page source.",
                    residual_risk="None once HTTPS is enforced site-wide.",
                )

    def _check_direct_object_attachments(self, endpoints: List[EndpointInfo]) -> None:
        numeric_attachment_urls = [
            e.url for e in endpoints if NUMERIC_PATH_SEGMENT_RE.search(e.url)
        ]
        if not numeric_attachment_urls:
            return
        example = numeric_attachment_urls[0]
        self.collector.add(
            title="Attachment Endpoints Use Sequential/Guessable Identifiers",
            severity="Medium", confidence="High", status="Confirmed",
            category="IDOR/BOLA", url=example,
            affected_component="Attachment identifier scheme",
            attack_path="Attacker increments/decrements attachment ID -> enumerates files",
            trust_boundary="Owner user -> Other users' attachments",
            blast_radius="Multiple Users",
            description="Attachment endpoints use small sequential numeric identifiers, "
                         "making enumeration trivial if authorization checks are weak or absent.",
            evidence=f"Example attachment URL(s): {', '.join(numeric_attachment_urls[:3])}",
            impact="Combined with any authorization gap, sequential IDs make it easy to "
                   "enumerate and access every attachment in the system.",
            recommendation="Even with correct authorization checks, consider using "
                           "non-sequential identifiers (UUIDs) for attachments as defense in "
                           "depth, and always enforce ownership checks server-side regardless "
                           "of ID predictability.",
            verification="This is a design observation, not a confirmed bypass; see the "
                         "access-control findings for authorization test results.",
            residual_risk="Low if strong ownership checks are confirmed; Medium otherwise.",
        )


class ApiSecurityChecker(BaseChecker):
    """API-focused checks: auth requirements, verbose errors, excessive data exposure."""

    SENSITIVE_FIELD_RE = re.compile(
        r'"(password|password_hash|hash|secret|token|ssn|ttoken|api_key|apikey|'
        r'auth_token|reset_token|session_id)"\s*:', re.IGNORECASE
    )

    def run(self) -> None:
        api_endpoints = [e for e in self.crawler.endpoints.values() if e.kind == "api"]
        anon_client = self.client.new_session_client()

        for e in api_endpoints:
            resp = anon_client.get(e.url)
            if resp is None:
                continue
            self._check_anonymous_access(e, resp)
            self._check_verbose_errors(e.url, resp)
            self._check_sensitive_fields(e.url, resp)
            self._check_unexpected_methods(e)

    def _check_anonymous_access(self, e: EndpointInfo, resp: requests.Response) -> None:
        if resp.status_code != 200:
            return
        content_type = resp.headers.get("Content-Type", "")
        if "json" not in content_type:
            return
        sensitive_path = re.search(r"student|grievance|attachment|warden|comment", e.url, re.IGNORECASE)
        if sensitive_path:
            self.collector.add(
                title="API Endpoint Returns Data Without Authenticated Session",
                severity="High", confidence="Medium", status="Potential",
                category="API Security", url=e.url,
                affected_component="API authentication middleware",
                attack_path="Unauthenticated request -> API -> JSON data returned",
                trust_boundary="Anonymous -> Authenticated API",
                blast_radius="Multiple Users",
                description="A fresh (no-cookie) request to a student/grievance/warden-related "
                             "API endpoint returned HTTP 200 with JSON content.",
                evidence=f"GET {e.url} -> {resp.status_code}, Content-Type: {content_type}, "
                         f"body sample: {truncate(resp.text, 150)}",
                impact="If this endpoint genuinely requires no authentication, it may leak "
                       "grievance or student data to anyone.",
                recommendation="Require and verify session authentication on this API route "
                               "before returning any data.",
                verification="Manually confirm with a clean session; some endpoints "
                             "legitimately return public, non-sensitive data.",
                residual_risk="Depends on manual confirmation of endpoint sensitivity.",
            )

    def _check_verbose_errors(self, url: str, resp: requests.Response) -> None:
        text_lower = (resp.text or "").lower()
        matched = next((sig for sig in FRAMEWORK_ERROR_SIGNATURES if sig in text_lower), None)
        if matched and resp.status_code >= 400:
            self.collector.add(
                title="Verbose API Error Disclosure",
                severity="Medium", confidence="Medium", status="Confirmed",
                category="Information Disclosure", url=url,
                affected_component="API error handling",
                attack_path="Attacker triggers error -> stack trace / internal detail leaked",
                trust_boundary="Application internals -> API response",
                blast_radius="Application-wide",
                description=f"An API error response contained a verbose error indicator "
                             f"('{matched}').",
                evidence=f"Status {resp.status_code}, matched signature '{matched}', "
                         f"sample: {truncate(resp.text, 150)}",
                impact="Verbose errors can leak internal implementation details, file paths, "
                       "or library versions useful for further attacks.",
                recommendation="Return generic error messages to clients; log full details "
                               "server-side only.",
                verification="Re-trigger the same request and inspect the response body.",
                residual_risk="Low once generic error handling is enforced globally.",
            )

    def _check_sensitive_fields(self, url: str, resp: requests.Response) -> None:
        if "json" not in resp.headers.get("Content-Type", ""):
            return
        match = self.SENSITIVE_FIELD_RE.search(resp.text or "")
        if match:
            self.collector.add(
                title="Excessive Data Exposure: Sensitive Field in API Response",
                severity="High", confidence="Medium", status="Potential",
                category="Excessive API Data Exposure", url=url,
                affected_component="API response serialization",
                attack_path="Client requests resource -> API over-returns internal fields",
                trust_boundary="Data layer -> API response -> Client",
                blast_radius="Multiple Users",
                description=f"The API response includes a field name suggestive of sensitive "
                             f"internal data ('{match.group(1)}').",
                evidence=f"Field name observed: {match.group(1)} (value not printed)",
                impact="Returning internal/sensitive fields (hashes, tokens, secrets) to "
                       "clients unnecessarily increases exposure if the response is logged, "
                       "cached, or intercepted.",
                recommendation="Use explicit response DTOs/serializers that allow-list only "
                               "the fields the client needs; never return password hashes or "
                               "raw tokens.",
                verification="Manually inspect the full response to confirm the field is "
                             "populated with live sensitive data (not null/placeholder).",
                residual_risk="Depends on manual confirmation of field contents.",
            )

    def _check_unexpected_methods(self, e: EndpointInfo) -> None:
        resp = self.client.request("OPTIONS", e.url)
        if resp is None:
            return
        allow = resp.headers.get("Allow", "")
        if allow and re.search(r"\bTRACE\b", allow, re.IGNORECASE):
            self.collector.add(
                title="TRACE Method Enabled",
                severity="Low", confidence="High", status="Confirmed",
                category="Security Misconfiguration", url=e.url,
                affected_component="HTTP method handling",
                attack_path="Attacker leverages TRACE for cross-site tracing style attacks",
                trust_boundary="HTTP method boundary",
                blast_radius="Application-wide",
                description="The TRACE HTTP method appears enabled per the Allow header.",
                evidence=f"Allow: {allow}",
                impact="TRACE can, in some legacy browser contexts, be used to bypass "
                       "HttpOnly protections (Cross-Site Tracing).",
                recommendation="Disable the TRACE method at the web server/reverse proxy level.",
                verification="Send an OPTIONS request and inspect the Allow header.",
                residual_risk="Low; mostly a defense-in-depth item on modern browsers.",
            )


class DisclosureChecker(BaseChecker):
    """Information disclosure: debug modes, stack traces, internal paths/IPs,
    exposed common sensitive files."""

    COMMON_PATHS = [
        "robots.txt", "sitemap.xml", ".env", ".git/HEAD", "debug",
        "package.json", ".git/config", "server-status",
    ]

    def run(self) -> None:
        for url, resp in self.crawler.pages.items():
            self._scan_body(url, resp.text or "")

        base = self.client.base_url.rstrip("/")
        for path in self.COMMON_PATHS:
            probe_url = f"{base}/{path}"
            resp = self.client.get(probe_url)
            if resp is None:
                continue
            if resp.status_code == 200 and len(resp.text or "") > 0:
                sensitivity = "High" if path in (".env", ".git/HEAD", ".git/config") else "Low"
                status_label = "Confirmed" if sensitivity == "High" else "Informational"
                self.collector.add(
                    title=f"Potentially Exposed Resource: /{path}",
                    severity=sensitivity, confidence="Medium", status=status_label,
                    category="Information Disclosure", url=probe_url,
                    affected_component="Static file serving",
                    attack_path="Attacker requests well-known path -> internal config/data exposed",
                    trust_boundary="Public internet -> Server filesystem/config",
                    blast_radius="Application-wide" if sensitivity == "High" else "Unknown",
                    description=f"A request to the well-known path '/{path}' returned HTTP 200.",
                    evidence=f"GET {probe_url} -> {resp.status_code}, "
                             f"Content-Type: {resp.headers.get('Content-Type', '')}, "
                             f"length: {len(resp.text or '')}",
                    impact="If this exposes real secrets (.env, .git) it can lead to full "
                           "application compromise. robots.txt/sitemap.xml exposure alone is normal.",
                    recommendation="Ensure secret/config files are never served by the web "
                                   "server; block .git and .env paths explicitly at the proxy level.",
                    verification="Manually fetch the URL and inspect content sensitivity "
                                 "(this scanner does not print discovered secrets).",
                    residual_risk="None once such paths return 403/404 by design.",
                )

    def _scan_body(self, url: str, body: str) -> None:
        lower = body.lower()

        for sig in FRAMEWORK_ERROR_SIGNATURES:
            if sig in lower:
                self.collector.add(
                    title="Framework/Debug Error Indicator in Response",
                    severity="Medium", confidence="Medium", status="Confirmed",
                    category="Information Disclosure", url=url,
                    affected_component="Error handling / debug mode",
                    attack_path="Attacker triggers error -> internal implementation details leaked",
                    trust_boundary="Application internals -> HTTP response",
                    blast_radius="Application-wide",
                    description=f"Response content matched a framework/debug error indicator "
                                 f"('{sig}').",
                    evidence=f"Matched signature: '{sig}'",
                    impact="Debug/verbose error output can reveal internal file structure, "
                           "dependency versions, and logic useful for further attacks.",
                    recommendation="Disable debug mode in production; return generic error pages.",
                    verification="Re-request the page/action that produced the error.",
                    residual_risk="Low once debug mode is confirmed disabled in production.",
                )
                break

        path_match = INTERNAL_PATH_RE.search(body)
        if path_match:
            self.collector.add(
                title="Internal Filesystem Path Disclosed",
                severity="Low", confidence="Medium", status="Confirmed",
                category="Information Disclosure", url=url,
                affected_component="Error/response output",
                attack_path="Attacker views response -> learns internal directory structure",
                trust_boundary="Application internals -> HTTP response",
                blast_radius="Application-wide",
                description="An internal filesystem path pattern was found in response content.",
                evidence=f"Pattern observed: {redact(path_match.group(0), keep=10)}",
                impact="Internal path disclosure aids attackers in crafting further "
                       "filesystem-targeted attacks (e.g. path traversal).",
                recommendation="Avoid leaking filesystem paths in error messages or comments "
                               "sent to the client.",
                verification="Inspect the response body directly.",
                residual_risk="Low; primarily aids reconnaissance rather than direct exploitation.",
            )

        ip_match = INTERNAL_IP_RE.search(body)
        if ip_match:
            try:
                ip_obj = ipaddress.ip_address(ip_match.group(0))
                if ip_obj.is_private or ip_obj.is_loopback:
                    self.collector.add(
                        title="Internal IP Address Disclosed",
                        severity="Low", confidence="Medium", status="Confirmed",
                        category="Information Disclosure", url=url,
                        affected_component="Error/response output",
                        attack_path="Attacker learns internal network topology from response",
                        trust_boundary="Internal network -> HTTP response",
                        blast_radius="Application-wide",
                        description="An internal/private IP address pattern was found in "
                                     "response content.",
                        evidence=f"Pattern observed: {redact(ip_match.group(0), keep=3)}",
                        impact="Internal network details can assist attackers who already "
                               "have partial access in pivoting further.",
                        recommendation="Avoid including internal IPs in any client-facing output.",
                        verification="Inspect the response body directly.",
                        residual_risk="Low; primarily reconnaissance value.",
                    )
            except ValueError:
                pass


class LoggingVisibilityChecker(BaseChecker):
    """
    Security event logging cannot generally be verified from outside the
    application. This module records an honest 'Manual Verification
    Required' status for each relevant event category rather than falsely
    asserting logging is absent.
    """

    EVENTS = [
        "Login failures", "Successful login", "Logout",
        "Authorization failures", "Grievance access",
        "Grievance status changes", "Attachment access", "Suspicious requests",
    ]

    def run(self) -> None:
        self.collector.add(
            title="Security-Relevant Event Logging Cannot Be Verified Externally",
            severity="Info", confidence="Low", status="Manual Verification Required",
            category="Insufficient Security Logging/Visibility", url=self.client.base_url,
            affected_component="Server-side audit logging",
            attack_path="N/A — visibility/detection concern, not a direct attack path",
            trust_boundary="Application -> Security monitoring",
            blast_radius="Unknown",
            description="This scanner cannot observe server-side logs from outside the "
                         "application. The following event categories should be manually "
                         "confirmed as logged with sufficient detail (timestamp, actor, "
                         "target object, outcome): " + "; ".join(self.EVENTS) + ".",
            evidence="No external signal is available to confirm or deny logging coverage.",
            impact="Without adequate logging of authorization failures, cross-account access "
                   "attempts, and attachment access, incident response and detection of "
                   "IDOR/privilege-escalation abuse will be significantly harder.",
            recommendation="Confirm each event category above is logged server-side with "
                           "enough context to reconstruct 'who accessed what, when, and with "
                           "what outcome', and that logs are shipped to a location an attacker "
                           "with application-level access cannot tamper with.",
            verification="Review server-side application/audit logs directly (outside the "
                         "scope of this external scanner) for each event category.",
            residual_risk="Unknown until manually verified.",
        )


# ---------------------------------------------------------------------------
# Authorized multi-account session setup (optional)
# ---------------------------------------------------------------------------

def build_authorized_sessions(base_url: str, credentials_path: Optional[str],
                               timeout: float, delay: float, verbose: bool) -> Dict[str, HttpClient]:
    """
    Optionally logs into up to three authorized test accounts (student_a,
    student_b, warden) using a JSON credentials file, to enable safe
    cross-account read comparisons. If no credentials file is supplied, or
    login attempts fail, returns an empty dict and access-control checks
    fall back to reporting 'Authorization Test Candidate' findings instead
    of confirmed cross-access results.

    This function performs AT MOST ONE login POST per configured account
    (never brute forcing) and only if the user has explicitly supplied
    credentials they are authorized to use.
    """
    sessions: Dict[str, HttpClient] = {}
    if not credentials_path:
        return sessions

    try:
        with open(credentials_path, "r", encoding="utf-8") as fh:
            creds = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"[!] Could not read credentials file '{credentials_path}': {exc}")
        return sessions

    # Common login endpoint guesses; the scanner tries a small, fixed set
    # and stops at the first that appears to succeed (2xx/3xx + a
    # session cookie set), rather than iterating destructively.
    login_paths = ["/login", "/api/login", "/api/auth/login", "/auth/login"]

    for role, cred in creds.items():
        username = cred.get("username")
        password = cred.get("password")
        if not username or not password:
            continue
        client = HttpClient(base_url, timeout, delay, verbose)
        logged_in = False
        for path in login_paths:
            url = urljoin(base_url, path)
            resp = client.request(
                "POST", url, allow_state_change=True,
                json={"username": username, "password": password},
            )
            if resp is None:
                continue
            if resp.status_code < 400 and (client.session.cookies or resp.status_code in (200, 201, 302)):
                logged_in = True
                break
        if logged_in:
            sessions[role] = client
            print(f"[+] Authorized session established for role '{role}'")
        else:
            print(f"[!] Could not establish an authorized session for role '{role}' "
                  f"(this is expected if the app's login path/shape differs — "
                  f"access-control checks will fall back to candidate reporting).")

    return sessions


# ---------------------------------------------------------------------------
# XML report generation
# ---------------------------------------------------------------------------

def generate_xml_report(path: str, config: ScanConfig, crawler: Crawler,
                         collector: FindingCollector, checks_run: List[str],
                         scan_started: datetime, scan_ended: datetime) -> None:
    def esc(value: Any) -> str:
        return saxutils.escape(str(value if value is not None else ""))

    summary = collector.summary()
    findings = collector.all()

    lines: List[str] = []
    lines.append('<?xml version="1.0" encoding="UTF-8"?>')
    lines.append("<SecurityAssessment>")
    lines.append(f"  <Scanner name=\"{esc(SCANNER_NAME)}\" version=\"{esc(SCANNER_VERSION)}\"/>")
    lines.append(f"  <Target>{esc(config.url)}</Target>")
    lines.append(f"  <ScanStart>{esc(scan_started.isoformat())}</ScanStart>")
    lines.append(f"  <ScanEnd>{esc(scan_ended.isoformat())}</ScanEnd>")
    lines.append("  <ChecksPerformed>")
    for c in checks_run:
        lines.append(f"    <Check>{esc(c)}</Check>")
    lines.append("  </ChecksPerformed>")

    lines.append("  <AttackSurface>")
    lines.append(f"    <PagesDiscovered>{len(crawler.visited)}</PagesDiscovered>")
    lines.append(f"    <FormsDiscovered>{len(crawler.forms)}</FormsDiscovered>")
    lines.append(f"    <ApiEndpointsDiscovered>{len(crawler.endpoints_by_kind('api'))}</ApiEndpointsDiscovered>")
    lines.append(f"    <AttachmentEndpointsDiscovered>{len(crawler.endpoints_by_kind('attachment'))}</AttachmentEndpointsDiscovered>")
    lines.append(f"    <ObjectReferenceEndpoints>{len(crawler.id_like_endpoints())}</ObjectReferenceEndpoints>")
    lines.append("    <Endpoints>")
    for e in list(crawler.endpoints.values())[:500]:
        lines.append(
            f'      <Endpoint url="{esc(e.url)}" method="{esc(e.method)}" '
            f'kind="{esc(e.kind)}" role_hint="{esc(e.role_hint)}" '
            f'params="{esc(",".join(e.params))}"/>'
        )
    lines.append("    </Endpoints>")
    lines.append("  </AttackSurface>")

    lines.append("  <SeveritySummary>")
    for sev in SEVERITIES:
        lines.append(f'    <Severity name="{sev}">{summary.get(sev, 0)}</Severity>')
    lines.append("  </SeveritySummary>")

    lines.append("  <Findings>")
    for f in findings:
        lines.append(f'    <Finding id="{esc(f.id)}">')
        for field_name in [
            "title", "severity", "confidence", "status", "category", "url",
            "affected_component", "attack_path", "trust_boundary", "blast_radius",
            "description", "evidence", "impact", "recommendation",
            "verification", "residual_risk",
        ]:
            tag = "".join(part.capitalize() for part in field_name.split("_"))
            value = getattr(f, field_name)
            lines.append(f"      <{tag}>{esc(value)}</{tag}>")
        lines.append("    </Finding>")
    lines.append("  </Findings>")

    lines.append("</SecurityAssessment>")

    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))


# ---------------------------------------------------------------------------
# PDF report generation (ReportLab)
# ---------------------------------------------------------------------------

def generate_pdf_report(path: str, config: ScanConfig, crawler: Crawler,
                         collector: FindingCollector, checks_run: List[str],
                         scan_started: datetime, scan_ended: datetime) -> None:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import LETTER
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        PageBreak, ListFlowable, ListItem,
    )

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="H1Custom", parent=styles["Heading1"], spaceAfter=12))
    styles.add(ParagraphStyle(name="H2Custom", parent=styles["Heading2"], spaceBefore=14, spaceAfter=8))
    styles.add(ParagraphStyle(name="FindingTitle", parent=styles["Heading3"],
                               spaceBefore=10, spaceAfter=4))
    styles.add(ParagraphStyle(name="Small", parent=styles["Normal"], fontSize=9, leading=12))
    styles.add(ParagraphStyle(name="Body", parent=styles["Normal"], fontSize=10, leading=14))

    SEVERITY_COLOR = {
        "Critical": colors.HexColor("#7a0d0d"),
        "High": colors.HexColor("#c0392b"),
        "Medium": colors.HexColor("#d68910"),
        "Low": colors.HexColor("#2e86c1"),
        "Info": colors.HexColor("#5d6d7e"),
    }

    story: List[Any] = []

    def p(text: str, style: str = "Body") -> Paragraph:
        return Paragraph(saxutils.escape(str(text)).replace("\n", "<br/>"), styles[style])

    # --- Title page / Executive Summary ------------------------------------------------
    story.append(Paragraph("HostelGrievance Security Assessment", styles["Title"]))
    story.append(Spacer(1, 6))
    story.append(p(f"Target: {config.url}", "Body"))
    story.append(p(f"Scan window: {scan_started.strftime('%Y-%m-%d %H:%M:%S UTC')} – "
                    f"{scan_ended.strftime('%Y-%m-%d %H:%M:%S UTC')}", "Body"))
    story.append(p(f"Generated by {SCANNER_NAME} v{SCANNER_VERSION}", "Small"))
    story.append(Spacer(1, 16))

    story.append(Paragraph("1. Executive Summary", styles["H1Custom"]))
    summary = collector.summary()
    total_findings = sum(summary.values())
    story.append(p(
        f"This report presents the results of an authorized, non-destructive security "
        f"assessment of the HostelGrievance application. The scan discovered "
        f"{len(crawler.visited)} pages, {len(crawler.forms)} forms, "
        f"{len(crawler.endpoints_by_kind('api'))} API-like endpoints, and "
        f"{len(crawler.endpoints_by_kind('attachment'))} attachment-related endpoints. "
        f"A total of {total_findings} findings were recorded across "
        f"{summary.get('Critical', 0)} Critical, {summary.get('High', 0)} High, "
        f"{summary.get('Medium', 0)} Medium, {summary.get('Low', 0)} Low, and "
        f"{summary.get('Info', 0)} Informational items. Findings related to broken "
        f"object-level authorization (IDOR/BOLA) and attachment handling were treated "
        f"as highest priority given the application's Student/Warden grievance model."
    ))
    story.append(Spacer(1, 10))

    sev_table_data = [["Severity", "Count"]] + [[s, str(summary.get(s, 0))] for s in SEVERITIES]
    sev_table = Table(sev_table_data, colWidths=[2.5 * inch, 1.5 * inch])
    sev_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
    ]))
    story.append(sev_table)
    story.append(PageBreak())

    # --- Attack surface ------------------------------------------------
    story.append(Paragraph("2. Application Attack Surface", styles["H1Custom"]))
    story.append(p(
        "The crawler operated same-origin only, with rate limiting, and performed no "
        "destructive requests. Discovered endpoints are summarized below (truncated for "
        "readability; full list is in the accompanying XML report)."
    ))
    endpoint_rows = [["URL", "Kind", "Role hint", "Params"]]
    for e in list(crawler.endpoints.values())[:40]:
        endpoint_rows.append([
            truncate(e.url, 60), e.kind, e.role_hint or "-", ", ".join(e.params[:5]),
        ])
    ep_table = Table(endpoint_rows, colWidths=[2.6 * inch, 0.8 * inch, 0.8 * inch, 1.8 * inch], repeatRows=1)
    ep_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#34495e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 7.5),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(ep_table)
    story.append(PageBreak())

    # --- Trust boundaries ------------------------------------------------
    story.append(Paragraph("3. Trust Boundaries", styles["H1Custom"]))
    story.append(p(
        "HostelGrievance's core trust boundaries are: (1) Anonymous vs. Authenticated "
        "session; (2) Student role vs. Warden role; (3) Owning student vs. other students "
        "for grievances, comments, and attachments; and (4) Client-supplied input vs. "
        "server-side data/query layers. Findings below are mapped to the boundary they cross."
    ))
    story.append(Spacer(1, 10))

    # --- Findings ------------------------------------------------
    story.append(Paragraph("4. Security Findings", styles["H1Custom"]))
    findings = collector.all()
    if not findings:
        story.append(p("No findings were recorded for the checks that were run."))
    for f in findings:
        color = SEVERITY_COLOR.get(f.severity, colors.black)
        story.append(Paragraph(
            f'<font color="{color.hexval() if hasattr(color, "hexval") else "#000000"}">'
            f'[{f.severity}] {f.id} — {saxutils.escape(f.title)}</font>',
            styles["FindingTitle"],
        ))
        meta_rows = [
            ["Status", f.status, "Confidence", f.confidence],
            ["Category", f.category, "Blast Radius", f.blast_radius],
            ["Trust Boundary", truncate(f.trust_boundary, 55), "Component", truncate(f.affected_component, 55)],
        ]
        meta_table = Table(meta_rows, colWidths=[1.1 * inch, 2.3 * inch, 1.1 * inch, 2.3 * inch])
        meta_table.setStyle(TableStyle([
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("BACKGROUND", (0, 0), (0, -1), colors.whitesmoke),
            ("BACKGROUND", (2, 0), (2, -1), colors.whitesmoke),
            ("GRID", (0, 0), (-1, -1), 0.3, colors.lightgrey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        story.append(meta_table)
        story.append(Spacer(1, 4))
        story.append(p(f"URL(s): {truncate(f.url, 200)}", "Small"))
        story.append(p(f"Attack path: {f.attack_path}", "Small"))
        story.append(Spacer(1, 4))
        story.append(p(f"<b>Description:</b> {f.description}", "Body"))
        story.append(p(f"<b>Evidence:</b> {f.evidence}", "Body"))
        story.append(p(f"<b>Impact:</b> {f.impact}", "Body"))
        story.append(p(f"<b>Recommendation:</b> {f.recommendation}", "Body"))
        story.append(p(f"<b>Verification:</b> {f.verification}", "Small"))
        story.append(p(f"<b>Residual risk:</b> {f.residual_risk}", "Small"))
        story.append(Spacer(1, 10))

    story.append(PageBreak())

    # --- Severity summary (repeat, standalone section per spec) ------------------------------------------------
    story.append(Paragraph("5. Severity Summary", styles["H1Custom"]))
    story.append(sev_table)
    story.append(Spacer(1, 12))

    # --- Blast radius analysis ------------------------------------------------
    story.append(Paragraph("6. Blast-Radius Analysis", styles["H1Custom"]))
    blast_counts: Dict[str, int] = {b: 0 for b in BLAST_RADII}
    for f in findings:
        blast_counts[f.blast_radius] = blast_counts.get(f.blast_radius, 0) + 1
    blast_rows = [["Blast Radius", "Findings"]] + [[b, str(blast_counts.get(b, 0))] for b in BLAST_RADII]
    blast_table = Table(blast_rows, colWidths=[2.5 * inch, 1.5 * inch])
    blast_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.whitesmoke, colors.white]),
    ]))
    story.append(blast_table)
    story.append(p(
        "Findings with a 'Multiple Users', 'Role-wide', or 'Application-wide' blast radius "
        "should be prioritized for remediation first, since a single flaw can compromise "
        "many students' or the whole application's data rather than one resource."
    ))
    story.append(Spacer(1, 12))

    # --- Recommended hardening ------------------------------------------------
    story.append(Paragraph("7. Recommended Hardening", styles["H1Custom"]))
    hardening_items = [
        "Enforce server-side ownership checks on every grievance/comment/attachment "
        "lookup: verify the object's owning student_id matches the session, or that "
        "the session holds the Warden role.",
        "Apply consistent role-based access control server-side for all Warden-only "
        "routes and actions; never rely on hiding buttons in the frontend.",
        "Use parameterized queries/ORM safe methods everywhere; never concatenate "
        "user input into SQL.",
        "HTML-encode all user-controlled output at render time; enable framework "
        "autoescaping by default.",
        "Set Secure, HttpOnly, and SameSite=Lax/Strict on all session cookies; pair "
        "with CSRF tokens for state-changing requests.",
        "Set Content-Security-Policy, Strict-Transport-Security, "
        "X-Content-Type-Options, X-Frame-Options, Referrer-Policy, and "
        "Permissions-Policy headers application-wide.",
        "Allow-list file extensions and content types for attachment uploads; store "
        "uploads outside the web root; require authentication and ownership checks "
        "on every download.",
        "Return generic error messages to clients; disable debug/verbose error output "
        "in production.",
        "Log authentication events, authorization failures, and all grievance/"
        "attachment access with enough detail to support incident investigation.",
    ]
    story.append(ListFlowable(
        [ListItem(p(item, "Body")) for item in hardening_items],
        bulletType="bullet",
    ))
    story.append(Spacer(1, 12))

    # --- Verification evidence ------------------------------------------------
    story.append(Paragraph("8. Verification Evidence", styles["H1Custom"]))
    story.append(p(
        "Evidence for each finding is included inline above (HTTP status codes, header "
        "presence/absence, matched signatures, and canary reflection results). No "
        "passwords, cookies, tokens, API keys, or student PII are included anywhere in "
        "this report; sensitive values are redacted or referenced by name/pattern only."
    ))
    story.append(Spacer(1, 12))

    # --- Residual risks ------------------------------------------------
    story.append(Paragraph("9. Residual Risks", styles["H1Custom"]))
    manual_review = [f for f in findings if f.status in ("Potential", "Manual Verification Required")]
    story.append(p(
        f"{len(manual_review)} of {len(findings)} findings are marked Potential or "
        f"Manual Verification Required. These represent residual risk that could not be "
        f"conclusively confirmed by this non-destructive external scan and should be "
        f"manually verified by the hardening team before being closed or accepted."
    ))
    story.append(Spacer(1, 12))

    # --- Scan configuration ------------------------------------------------
    story.append(Paragraph("10. Scan Configuration", styles["H1Custom"]))
    config_rows = [
        ["Target", config.url],
        ["Max pages", str(config.max_pages)],
        ["Timeout (s)", str(config.timeout)],
        ["Delay between requests (s)", str(config.delay)],
        ["Checks performed", ", ".join(checks_run)],
        ["Authorized multi-account testing", "Enabled" if config.credentials_path else "Not configured"],
    ]
    cfg_table = Table(config_rows, colWidths=[2.2 * inch, 4.3 * inch])
    cfg_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), colors.whitesmoke),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.lightgrey),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(cfg_table)

    doc = SimpleDocTemplate(
        path, pagesize=LETTER,
        topMargin=0.75 * inch, bottomMargin=0.75 * inch,
        leftMargin=0.75 * inch, rightMargin=0.75 * inch,
        title="HostelGrievance Security Assessment",
    )
    doc.build(story)


# ---------------------------------------------------------------------------
# CLI / orchestration
# ---------------------------------------------------------------------------

def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="security_scanner.py",
        description=f"{SCANNER_NAME} — authorized, non-destructive assessment tool "
                     f"for the HostelGrievance application.",
    )
    parser.add_argument("--url", required=True, help="Target base URL, e.g. https://target.example")
    parser.add_argument("--all", action="store_true", help="Run all safe checks")

    parser.add_argument("--crawl", action="store_true", help="Crawl application (implied by other checks)")
    parser.add_argument("--headers", action="store_true", help="Security headers check")
    parser.add_argument("--cookies", action="store_true", help="Cookie/session security check")
    parser.add_argument("--auth", action="store_true", help="Authentication checks")
    parser.add_argument("--access-control", action="store_true", help="Authorization/IDOR checks")
    parser.add_argument("--input", action="store_true", help="Input validation checks")
    parser.add_argument("--xss", action="store_true", help="Safe XSS checks")
    parser.add_argument("--sqli", action="store_true", help="Conservative SQL-error checks")
    parser.add_argument("--files", action="store_true", help="File upload/download security checks")
    parser.add_argument("--api", action="store_true", help="API security checks")
    parser.add_argument("--disclosure", action="store_true", help="Information disclosure checks")
    parser.add_argument("--logging-check", action="store_true", help="Security logging indicators")

    parser.add_argument("--max-pages", type=int, default=60, help="Maximum pages to crawl")
    parser.add_argument("--timeout", type=float, default=8.0, help="HTTP timeout (seconds)")
    parser.add_argument("--delay", type=float, default=0.15, help="Delay between requests (seconds)")

    parser.add_argument("--output", default="security-tool.xml", help="XML output path")
    parser.add_argument("--pdf-output", default="security-report.pdf", help="PDF output path")
    parser.add_argument("--verbose", action="store_true", help="Detailed output")

    parser.add_argument(
        "--credentials", dest="credentials_path", default=None,
        help="Optional JSON file with authorized test account credentials "
             "(student_a, student_b, warden) for safe cross-account access comparison.",
    )
    parser.add_argument(
        "--enable-upload-probe", action="store_true",
        help="Explicitly allow sending ONE harmless text file to discovered upload forms "
             "using an authorized session, to observe validation behavior. Never enabled by default.",
    )

    return parser


def resolve_config(args: argparse.Namespace) -> ScanConfig:
    any_specific = any([
        args.headers, args.cookies, args.auth, args.access_control, args.input,
        args.xss, args.sqli, args.files, args.api, args.disclosure, args.logging_check,
    ])
    run_all = args.all or not any_specific

    return ScanConfig(
        url=args.url.rstrip("/"),
        max_pages=args.max_pages,
        timeout=args.timeout,
        delay=args.delay,
        verbose=args.verbose,
        credentials_path=args.credentials_path,
        output_xml=args.output,
        output_pdf=args.pdf_output,
        do_crawl=True,  # crawling underlies every other check
        do_headers=run_all or args.headers,
        do_cookies=run_all or args.cookies,
        do_auth=run_all or args.auth,
        do_access_control=run_all or args.access_control,
        do_input=run_all or args.input,
        do_xss=run_all or args.xss,
        do_sqli=run_all or args.sqli,
        do_files=run_all or args.files,
        do_api=run_all or args.api,
        do_disclosure=run_all or args.disclosure,
        do_logging_check=run_all or args.logging_check,
        enable_upload_probe=args.enable_upload_probe,
    )


def validate_target(url: str) -> bool:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        print(f"[!] Invalid target URL: {url}")
        return False
    return True


def print_banner(config: ScanConfig) -> None:
    print("=" * 60)
    print(" HostelGrievance Security Assessment")
    print("=" * 60)
    print(f"\nTarget: {config.url}\n")


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_arg_parser()
    args = parser.parse_args(argv)
    config = resolve_config(args)

    if not validate_target(config.url):
        return 1

    print_banner(config)
    scan_started = datetime.now(timezone.utc)

    client = HttpClient(config.url, timeout=config.timeout, delay=config.delay, verbose=config.verbose)
    crawler = Crawler(client, max_pages=config.max_pages, verbose=config.verbose)

    print("Crawling...")
    crawler.crawl(config.url)
    print(f"Pages: {len(crawler.visited)}")
    print(f"Forms: {len(crawler.forms)}")
    print(f"APIs: {len(crawler.endpoints_by_kind('api'))}")
    print(f"Attachments: {len(crawler.endpoints_by_kind('attachment'))}\n")

    collector = FindingCollector()
    checks_run: List[str] = ["crawl"]

    sessions = build_authorized_sessions(
        config.url, config.credentials_path, config.timeout, config.delay, config.verbose,
    )

    print("Running checks...\n")

    if config.do_headers:
        checks_run.append("headers")
        HeaderChecker(client, crawler, collector, config).run()

    if config.do_cookies:
        checks_run.append("cookies")
        CookieChecker(client, crawler, collector, config).run()

    if config.do_auth:
        checks_run.append("auth")
        AuthChecker(client, crawler, collector, config).run()

    if config.do_access_control:
        checks_run.append("access-control")
        AccessControlChecker(client, crawler, collector, config, sessions=sessions).run()

    if config.do_input:
        checks_run.append("input")
        InputChecker(client, crawler, collector, config).run()

    if config.do_xss:
        checks_run.append("xss")
        XssChecker(client, crawler, collector, config).run()

    if config.do_sqli:
        checks_run.append("sqli")
        SqliChecker(client, crawler, collector, config).run()

    if config.do_files:
        checks_run.append("files")
        FileSecurityChecker(client, crawler, collector, config).run()

    if config.do_api:
        checks_run.append("api")
        ApiSecurityChecker(client, crawler, collector, config).run()

    if config.do_disclosure:
        checks_run.append("disclosure")
        DisclosureChecker(client, crawler, collector, config).run()

    if config.do_logging_check:
        checks_run.append("logging-check")
        LoggingVisibilityChecker(client, crawler, collector, config).run()

    scan_ended = datetime.now(timezone.utc)

    findings = collector.all()
    for f in findings:
        print(f"[{f.severity.upper()}] {f.id} {f.title}")

    summary = collector.summary()
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    for sev in SEVERITIES:
        print(f"{sev + ':':<10}{summary.get(sev, 0)}")

    print("\nGenerating reports...")
    try:
        generate_xml_report(config.output_xml, config, crawler, collector, checks_run,
                             scan_started, scan_ended)
        print(f"\u2713 {config.output_xml}")
    except Exception as exc:  # pragma: no cover
        print(f"[!] Failed to write XML report: {exc}")

    try:
        generate_pdf_report(config.output_pdf, config, crawler, collector, checks_run,
                             scan_started, scan_ended)
        print(f"\u2713 {config.output_pdf}")
    except Exception as exc:  # pragma: no cover
        print(f"[!] Failed to write PDF report: {exc}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
